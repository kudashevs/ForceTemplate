<?php
$_lang['area_forcetemplate.main'] = 'Основные';

$_lang['setting_forcetemplate.response'] = 'Cache-control ответ';
$_lang['setting_forcetemplate.response_desc'] = 'Устанавливает значение ответа для Cache-control заголовка. Доступные значения: "private", "public".';
$_lang['setting_forcetemplate.maxage'] = 'Cache-control max-age';
$_lang['setting_forcetemplate.maxage_desc'] = 'Устанавливает значение max-age для Cache-control заголовка в секундах. По умолчанию 3600.';