--------------------
ForceTemplate
--------------------
Author: Kudashev Serge <kudashevs@gmail.com>
--------------------

MODx Revolution plugin which force template set for given parents

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/ForceTemplate/issues