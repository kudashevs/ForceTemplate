<?php
$_lang['area_forcetemplate.main'] = 'Основные';

$_lang['setting_forcetemplate.rules'] = 'Правила';
$_lang['setting_forcetemplate.rules_desc'] = 'Устанавливает правило использования в формате "parent_id:template:level" разделенные символом пайп (|) или двойным пайп (||). Пример: 3:1|4:2:5.';
$_lang['setting_forcetemplate.quick_create'] = 'Использовать меню "Быстро создать"';
$_lang['setting_forcetemplate.quick_create_desc'] = 'Позволяет использовать принудительную установку шаблона для меню "Быстро создать" в дереве документов. По умолчанию true.';
$_lang['setting_forcetemplate.parents_check'] = 'Проверка дублирования родителей';
$_lang['setting_forcetemplate.parents_check_desc'] = 'Проверяет дублирование родительских id в правилах и сообщает в лог при дублировании. По умолчанию false.';